package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.manager.ShizukuManager
import com.example.repository.AppInfo
import com.example.repository.AppRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

enum class OperationStatus {
    PENDING, IN_PROGRESS, SUCCESS, FAILED
}

data class UninstallReport(
    val appName: String,
    val packageName: String,
    val status: OperationStatus,
    val message: String?
)

sealed class UiEvent {
    data class ShowSnackbar(val message: String) : UiEvent()
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AppRepository(application)
    private val shizukuManager = ShizukuManager(application)

    // Shizuku Connection States
    private val _isShizukuInstalled = MutableStateFlow(false)
    val isShizukuInstalled: StateFlow<Boolean> = _isShizukuInstalled.asStateFlow()

    private val _isShizukuRunning = MutableStateFlow(false)
    val isShizukuRunning: StateFlow<Boolean> = _isShizukuRunning.asStateFlow()

    private val _hasShizukuPermission = MutableStateFlow(false)
    val hasShizukuPermission: StateFlow<Boolean> = _hasShizukuPermission.asStateFlow()

    private val _showShizukuRequiredDialog = MutableStateFlow(false)
    val showShizukuRequiredDialog: StateFlow<Boolean> = _showShizukuRequiredDialog.asStateFlow()

    fun triggerShizukuRequiredDialog() {
        _showShizukuRequiredDialog.value = true
    }

    fun dismissShizukuRequiredDialog() {
        _showShizukuRequiredDialog.value = false
    }

    fun isShizukuConnected(): Boolean {
        refreshShizukuStatus()
        return _isShizukuRunning.value && _hasShizukuPermission.value
    }

    // Apps Loading States
    private val _isAppsLoading = MutableStateFlow(false)
    val isAppsLoading: StateFlow<Boolean> = _isAppsLoading.asStateFlow()

    private val _installedApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val installedApps: StateFlow<List<AppInfo>> = _installedApps.asStateFlow()

    private val _uninstalledApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val uninstalledApps: StateFlow<List<AppInfo>> = _uninstalledApps.asStateFlow()

    // UI Filtering and Search
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _filterShowUserApps = MutableStateFlow(true)
    val filterShowUserApps: StateFlow<Boolean> = _filterShowUserApps.asStateFlow()

    private val _filterShowSystemApps = MutableStateFlow(true)
    val filterShowSystemApps: StateFlow<Boolean> = _filterShowSystemApps.asStateFlow()

    // Multiple selection
    private val _selectedPackageNames = MutableStateFlow<Set<String>>(emptySet())
    val selectedPackageNames: StateFlow<Set<String>> = _selectedPackageNames.asStateFlow()

    // UI Action Notifications
    private val _uiEvent = MutableSharedFlow<UiEvent>()
    val uiEvent: SharedFlow<UiEvent> = _uiEvent.asSharedFlow()

    // Uninstall / Restore Reports
    private val _uninstallReports = MutableStateFlow<List<UninstallReport>?>(null)
    val uninstallReports: StateFlow<List<UninstallReport>?> = _uninstallReports.asStateFlow()

    private val _operationIsUninstall = MutableStateFlow(true)
    val operationIsUninstall: StateFlow<Boolean> = _operationIsUninstall.asStateFlow()

    fun dismissUninstallReports() {
        _uninstallReports.value = null
    }

    // Shizuku permission grant listener
    private val shizukuPermissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == ShizukuManager.PERMISSION_REQUEST_CODE) {
            refreshShizukuStatus()
            if (grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                emitUiEvent(UiEvent.ShowSnackbar("Permissão concedida pelo Shizuku!"))
                loadInstalledApps()
            } else {
                emitUiEvent(UiEvent.ShowSnackbar("Permissão negada pelo Shizuku."))
            }
        }
    }

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        refreshShizukuStatus()
    }
    
    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        refreshShizukuStatus()
    }

    init {
        try {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            shizukuManager.addPermissionListener(shizukuPermissionListener)
        } catch (e: Throwable) {
            Log.e("MainViewModel", "Erro ao inicializar Shizuku listeners", e)
        }
        refreshShizukuStatus()
        loadInstalledApps()
    }

    override fun onCleared() {
        super.onCleared()
        try {
            Shizuku.removeBinderReceivedListener(binderReceivedListener)
            Shizuku.removeBinderDeadListener(binderDeadListener)
            shizukuManager.removePermissionListener(shizukuPermissionListener)
        } catch (e: Throwable) {
            Log.e("MainViewModel", "Erro ao remover Shizuku listeners", e)
        }
    }

    /**
     * Atualiza os estados de integridade e conexão com o Shizuku Binder.
     */
    fun refreshShizukuStatus() {
        val installed = shizukuManager.isInstalled()
        val running = shizukuManager.isRunning()
        val permission = if (running) shizukuManager.hasPermission() else false

        _isShizukuInstalled.value = installed
        _isShizukuRunning.value = running
        _hasShizukuPermission.value = permission
    }

    /**
     * Solicita permissão ao Shizuku.
     */
    fun requestShizukuPermission() {
        if (!shizukuManager.isInstalled()) {
            emitUiEvent(UiEvent.ShowSnackbar("Shizuku não instalado. Baixe o Shizuku primeiro."))
            return
        }
        if (!shizukuManager.isRunning()) {
            emitUiEvent(UiEvent.ShowSnackbar("O Shizuku está desligado. Inicie o serviço no app Shizuku."))
            return
        }
        shizukuManager.requestPermission()
    }

    /**
     * Carrega a lista completa de aplicativos de forma assíncrona e otimizada.
     */
    fun loadInstalledApps() {
        viewModelScope.launch {
            _isAppsLoading.value = true
            try {
                val (installed, uninstalled) = repository.getAllApps()
                _installedApps.value = installed
                _uninstalledApps.value = uninstalled
                clearSelection()
            } catch (e: Exception) {
                Log.e("MainViewModel", "Erro ao carregar aplicativos", e)
                emitUiEvent(UiEvent.ShowSnackbar("Falha ao carregar apps: ${e.localizedMessage}"))
            } finally {
                _isAppsLoading.value = false
            }
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setFilterShowUserApps(show: Boolean) {
        _filterShowUserApps.value = show
    }

    fun setFilterShowSystemApps(show: Boolean) {
        _filterShowSystemApps.value = show
    }

    fun processImportedFile(context: Context, uri: Uri, isForRestore: Boolean = false) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                val text = inputStream?.bufferedReader()?.use { it.readText() } ?: return@launch
                val importedPackages = text.lines().map { it.trim() }.filter { it.isNotEmpty() }.toSet()
                
                withContext(Dispatchers.Main) {
                    val availablePackages = if (isForRestore) {
                        _uninstalledApps.value.map { it.packageName }.toSet()
                    } else {
                        _installedApps.value.filter { !it.isCritical }.map { it.packageName }.toSet()
                    }
                    val validPackagesToSelect = importedPackages.intersect(availablePackages)
                    
                    if (validPackagesToSelect.isNotEmpty()) {
                        _selectedPackageNames.update { it + validPackagesToSelect }
                        emitUiEvent(UiEvent.ShowSnackbar("${validPackagesToSelect.size} pacotes selecionados."))
                    } else {
                        val listName = if (isForRestore) "lixeira" else "instalados"
                        emitUiEvent(UiEvent.ShowSnackbar("Nenhum pacote válido encontrado para selecionar em '$listName'."))
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    emitUiEvent(UiEvent.ShowSnackbar("Erro ao importar arquivo."))
                }
            }
        }
    }

    fun exportUninstalledApps(context: Context, uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val textToSave = _uninstalledApps.value.joinToString("\n") { it.packageName }
                context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                    outputStream.bufferedWriter().use { writer ->
                        writer.write(textToSave)
                    }
                }
                withContext(Dispatchers.Main) {
                    emitUiEvent(UiEvent.ShowSnackbar("Lista de desinstalados salva com sucesso!"))
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    emitUiEvent(UiEvent.ShowSnackbar("Erro ao salvar lista: ${e.localizedMessage}"))
                }
            }
        }
    }

    fun toggleAppSelection(packageName: String) {
        _selectedPackageNames.update { current ->
            if (current.contains(packageName)) current - packageName else current + packageName
        }
    }

    fun clearSelection() {
        _selectedPackageNames.value = emptySet()
    }

    /**
     * Comando 1: Desinstalar aplicativo (individual ou em lote via Shizuku).
     */
    fun uninstallSelectedApps() {
        if (!isShizukuConnected()) {
            triggerShizukuRequiredDialog()
            return
        }
        _operationIsUninstall.value = true
        val packagesToUninstall = _selectedPackageNames.value.toList()
        if (packagesToUninstall.isEmpty()) return

        viewModelScope.launch(Dispatchers.IO) {
            val currentInstalled = _installedApps.value
            val reports = packagesToUninstall.mapNotNull { pkg ->
                val app = currentInstalled.find { it.packageName == pkg }
                if (app != null) UninstallReport(app.appName, app.packageName, OperationStatus.PENDING, null) else null
            }.toMutableList()
            
            _uninstallReports.value = reports.toList()

            for (i in reports.indices) {
                val currentReport = reports[i]
                reports[i] = currentReport.copy(status = OperationStatus.IN_PROGRESS)
                _uninstallReports.value = reports.toList()
                
                val app = currentInstalled.find { it.packageName == currentReport.packageName } ?: continue
                
                val result = shizukuManager.uninstallApp(app.packageName)
                if (result) {
                    reports[i] = currentReport.copy(status = OperationStatus.SUCCESS, message = null)
                    
                    _installedApps.update { list -> list.filter { it.packageName != app.packageName } }
                    _uninstalledApps.update { list -> (list + app).sortedBy { it.appName.lowercase() } }
                } else {
                    reports[i] = currentReport.copy(status = OperationStatus.FAILED, message = "Falha ao desinstalar")
                }
                _uninstallReports.value = reports.toList()
            }

            clearSelection()

            // Atualização assíncrona dos estados de fundo
            try {
                val (refreshedInstalled, refreshedUninstalled) = repository.getAllApps()
                _installedApps.value = refreshedInstalled
                _uninstalledApps.value = refreshedUninstalled
            } catch (e: Exception) {
                Log.e("MainViewModel", "Erro na sincronização em segundo plano", e)
            }
        }
    }

    /**
     * Comando 2: Restaurar aplicativo (individual ou em lote via Shizuku).
     */
    fun restoreSelectedApps() {
        if (!isShizukuConnected()) {
            triggerShizukuRequiredDialog()
            return
        }
        _operationIsUninstall.value = false
        val packagesToRestore = _selectedPackageNames.value.toList()
        if (packagesToRestore.isEmpty()) return

        viewModelScope.launch(Dispatchers.IO) {
            val currentUninstalled = _uninstalledApps.value
            val reports = packagesToRestore.mapNotNull { pkg ->
                val app = currentUninstalled.find { it.packageName == pkg }
                if (app != null) UninstallReport(app.appName, app.packageName, OperationStatus.PENDING, null) else null
            }.toMutableList()
            
            _uninstallReports.value = reports.toList()

            for (i in reports.indices) {
                val currentReport = reports[i]
                reports[i] = currentReport.copy(status = OperationStatus.IN_PROGRESS)
                _uninstallReports.value = reports.toList()
                
                val app = currentUninstalled.find { it.packageName == currentReport.packageName } ?: continue
                
                val result = shizukuManager.restoreApp(app.packageName)
                if (result) {
                    reports[i] = currentReport.copy(status = OperationStatus.SUCCESS, message = null)
                    
                    _uninstalledApps.update { list -> list.filter { it.packageName != app.packageName } }
                    _installedApps.update { list -> (list + app).sortedBy { it.appName.lowercase() } }
                } else {
                    reports[i] = currentReport.copy(status = OperationStatus.FAILED, message = "Falha ao restaurar")
                }
                _uninstallReports.value = reports.toList()
            }

            clearSelection()

            // Atualização assíncrona dos estados de fundo
            try {
                val (refreshedInstalled, refreshedUninstalled) = repository.getAllApps()
                _installedApps.value = refreshedInstalled
                _uninstalledApps.value = refreshedUninstalled
            } catch (e: Exception) {
                Log.e("MainViewModel", "Erro na sincronização em segundo plano", e)
            }
        }
    }

    private fun emitUiEvent(event: UiEvent) {
        viewModelScope.launch {
            _uiEvent.emit(event)
        }
    }
}
