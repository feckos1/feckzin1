package com.example.manager

import android.content.Context
import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

class ShizukuManager(private val context: Context) {

    companion object {
        const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
        const val PERMISSION_REQUEST_CODE = 1412
    }

    fun isInstalled(): Boolean {
        return try {
            context.packageManager.getPackageInfoCompat(SHIZUKU_PACKAGE, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    fun isRunning(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun hasPermission(): Boolean {
        if (!isRunning()) return false
        return try {
            if (Shizuku.isPreV11()) true else Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Throwable) {
            false
        }
    }

    fun requestPermission() {
        if (!isRunning() || Shizuku.isPreV11()) return
        try { Shizuku.requestPermission(PERMISSION_REQUEST_CODE) } catch (e: Throwable) {}
    }

    fun addPermissionListener(listener: Shizuku.OnRequestPermissionResultListener) {
        try { Shizuku.addRequestPermissionResultListener(listener) } catch (e: Throwable) {}
    }

    fun removePermissionListener(listener: Shizuku.OnRequestPermissionResultListener) {
        try { Shizuku.removeRequestPermissionResultListener(listener) } catch (e: Throwable) {}
    }

    private val newProcessMethod by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        ).apply { isAccessible = true }
    }

    private fun newShizukuProcess(command: Array<String>): Process {
        return newProcessMethod.invoke(null, command, null, null) as Process
    }

    private fun executeCommandRaw(command: Array<String>): Boolean {
        return try {
            val process = newShizukuProcess(command)
            val stdOut = process.inputStream.bufferedReader().use { it.readText() }.trim()
            val stdErr = process.errorStream.bufferedReader().use { it.readText() }.trim()
            val exitCode = process.waitFor()
            exitCode == 0 && !stdOut.contains("Failure", ignoreCase = true) && !stdErr.contains("Failure", ignoreCase = true) && !stdOut.contains("Exception", ignoreCase = true)
        } catch (e: Throwable) {
            false
        }
    }

    private fun isAppInstalledLocal(packageName: String): Boolean {
        return try {
            val appInfo = context.packageManager.getApplicationInfoCompat(packageName, 0)
            appInfo.enabled
        } catch (e: Exception) {
            false
        }
    }

    suspend fun uninstallApp(packageName: String): Boolean = withContext(Dispatchers.IO) {
        if (!isRunning() || !hasPermission()) return@withContext false
        
        // Primary: Uninstall for user 0
        val uninstalled = executeCommandRaw(arrayOf("pm", "uninstall", "--user", "0", packageName))
        if (uninstalled || !isAppInstalledLocal(packageName)) {
            return@withContext true
        }
        
        // Fallback: Disable for user 0
        val disabled = executeCommandRaw(arrayOf("pm", "disable-user", "--user", "0", packageName))
        if (disabled || !isAppInstalledLocal(packageName)) {
            return@withContext true
        }
        
        false
    }

    suspend fun restoreApp(packageName: String): Boolean = withContext(Dispatchers.IO) {
        if (!isRunning() || !hasPermission()) return@withContext false
        
        // Primary: Install existing package for user 0
        val restored = executeCommandRaw(arrayOf("cmd", "package", "install-existing", "--user", "0", packageName))
        if (restored || isAppInstalledLocal(packageName)) {
            return@withContext true
        }

        // Fallback: Enable if it was disabled rather than uninstalled
        val enabled = executeCommandRaw(arrayOf("pm", "enable", "--user", "0", packageName))
        if (enabled || isAppInstalledLocal(packageName)) {
            return@withContext true
        }
        
        false
    }
}

private fun PackageManager.getPackageInfoCompat(packageName: String, flags: Int): android.content.pm.PackageInfo {
    return if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
        getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(flags.toLong()))
    } else {
        @Suppress("DEPRECATION")
        getPackageInfo(packageName, flags)
    }
}

private fun PackageManager.getApplicationInfoCompat(packageName: String, flags: Int): android.content.pm.ApplicationInfo {
    return if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
        getApplicationInfo(packageName, PackageManager.ApplicationInfoFlags.of(flags.toLong()))
    } else {
        @Suppress("DEPRECATION")
        getApplicationInfo(packageName, flags)
    }
}
