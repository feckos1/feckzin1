package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Primary & State Colors
val PrimaryLight = Color(0xFF2563EB)      // Tailwind Blue 600
val PrimaryDark = Color(0xFF3B82F6)       // Tailwind Blue 500 (better contrast in dark mode)
val SuccessColor = Color(0xFF10B981)      // Tailwind Emerald 500
val ErrorColor = Color(0xFFEF4444)        // Tailwind Red 500

// Dark Theme (Midnight Slate) - Deep, premium blue-tinted gray
val DarkBackground = Color(0xFF0F172A)    // Slate 900
val DarkSurface = Color(0xFF1E293B)       // Slate 800
val DarkSurfaceVariant = Color(0xFF334155) // Slate 700
val DarkOutline = Color(0xFF475569)       // Slate 600
val DarkTextPrimary = Color(0xFFF8FAFC)   // Slate 50
val DarkTextSecondary = Color(0xFF94A3B8) // Slate 400

// Light Theme (Pearl Slate) - Clean, airy, soft cool gray
val LightBackground = Color(0xFFF8FAFC)   // Slate 50
val LightSurface = Color(0xFFFFFFFF)      // Pure White
val LightSurfaceVariant = Color(0xFFE2E8F0) // Slate 200
val LightOutline = Color(0xFFCBD5E1)      // Slate 300
val LightTextPrimary = Color(0xFF0F172A)  // Slate 900
val LightTextSecondary = Color(0xFF475569) // Slate 600
