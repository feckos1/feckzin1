package com.example.repository

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class AppInfo(
    val packageName: String,
    val appName: String,
    val isSystemApp: Boolean,
    val isCritical: Boolean
)

class AppRepository(context: Context) {

    private val packageManager: PackageManager = context.packageManager
    private val launcherPackage: String? by lazy { getDefaultLauncherInternal() }

    /**
     * Carrega tanto os aplicativos instalados quanto os desinstalados/desativados
     * em uma única consulta otimizada ao PackageManager.
     */
    suspend fun getAllApps(): Pair<List<AppInfo>, List<AppInfo>> = withContext(Dispatchers.IO) {
        val currentLauncher = launcherPackage
        val packages = try {
            @Suppress("DEPRECATION")
            packageManager.getInstalledPackagesCompat(
                PackageManager.MATCH_UNINSTALLED_PACKAGES or PackageManager.MATCH_DISABLED_COMPONENTS
            )
        } catch (e: Exception) {
            emptyList()
        }

        val installed = ArrayList<AppInfo>(packages.size)
        val uninstalled = ArrayList<AppInfo>()

        for (pkg in packages) {
            val appInfo = pkg.applicationInfo ?: continue
            val isInstalled = (appInfo.flags and ApplicationInfo.FLAG_INSTALLED) != 0
            val isEnabled = appInfo.enabled
            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            val appName = try {
                appInfo.loadLabel(packageManager).toString()
            } catch (e: Exception) {
                pkg.packageName
            }
            val info = AppInfo(
                packageName = pkg.packageName,
                appName = appName,
                isSystemApp = isSystem,
                isCritical = isCriticalApp(pkg.packageName, currentLauncher)
            )

            if (isInstalled && isEnabled) {
                installed.add(info)
            } else {
                uninstalled.add(info)
            }
        }

        installed.sortBy { it.appName.lowercase() }
        uninstalled.sortBy { it.appName.lowercase() }

        Pair(installed, uninstalled)
    }

    private fun getDefaultLauncherInternal(): String? {
        return try {
            val intent = Intent(Intent.ACTION_MAIN).apply { addCategory(Intent.CATEGORY_HOME) }
            val resolveInfo = packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
            resolveInfo?.activityInfo?.packageName
        } catch (e: Exception) {
            null
        }
    }

    private fun isCriticalApp(packageName: String, defaultLauncher: String?): Boolean {
        return packageName == "android" ||
               packageName == "com.android.systemui" ||
               packageName == "com.android.settings" ||
               packageName == "com.google.android.gms" ||
               packageName == "moe.shizuku.privileged.api" ||
               packageName == "dev.rikka.shizuku" ||
               packageName == defaultLauncher
    }
}

private fun PackageManager.getInstalledPackagesCompat(flags: Int): List<android.content.pm.PackageInfo> {
    return if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
        getInstalledPackages(PackageManager.PackageInfoFlags.of(flags.toLong()))
    } else {
        @Suppress("DEPRECATION")
        getInstalledPackages(flags)
    }
}

